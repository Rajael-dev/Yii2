<?php

class VendaFormCest
{
    public function _before(\FunctionalTester $I)
    {
        $I->amOnRoute('venda\create');
    }

    public function DataDaVenda(\FunctionalTester $I)
    {
        $I->see('Data da Venda');

    }

    public function SubmetendoVazio(\FunctionalTester $I)
    {
        $I->submitForm(Form,[]);
        $I->see('Não pode ficar');
    }

    public function Submetendo(\FunctionalTester $I)
    {
        $I->submitForm('form',[
            'Venda[data]' => '12/10/2019',
            'Venda[data_pagamento]' => '13/10/2019'
        ]);
        $I->see('Update');
        $I->see('Delete');
    }
}