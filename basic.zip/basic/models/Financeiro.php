<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "financeiro".
 *
 * @property int $id
 * @property string $data
 * @property int $forma
 * @property float $valor
 * @property int $id_dr
 * @property int $id_cliente
 * @property string|null $datacheque
 * @property int|null $parcelamentocartao
 *
 * @property Odonto $dr
 * @property Paciente $cliente
 */
class Financeiro extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'financeiro';
    }

    /**
     * {@inheritdoc}
     */

    public function rules()
    {
        return [
            [['data', 'datacheque'], 'safe'],
            [['forma', 'valor', 'id_dr', 'id_cliente'], 'required'],
            [['forma', 'id_dr', 'id_cliente', 'parcelamentocartao'], 'default', 'value' => null],
            [['forma', 'id_dr', 'id_cliente', 'parcelamentocartao'], 'integer'],
            //[['data'], 'compare', 'compareAttribute' => 'created_at', 'operator' => '<='],
            [['id_dr'], 'exist', 'skipOnError' => true, 'targetClass' => Odonto::className(), 'targetAttribute' => ['id_dr' => 'id']],
            [['id_cliente'], 'exist', 'skipOnError' => true, 'targetClass' => Paciente::className(), 'targetAttribute' => ['id_cliente' => 'id']],
            [['valor'], 'number', 'numberPattern' => '/^\s*[-+]?[0-9]*[.,]?[0-9]+([eE][-+]?[0-9]+)?\s*$/'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'data' => 'Data',
            'forma' => 'Forma de Pagamento',
            'valor' => 'Valor',
            'id_dr' => 'Odonto',
            'id_cliente' => 'Paciente',
            'datacheque' => 'Datacheque',
            'parcelamentocartao' => 'Parcelamentocartao',
            'created_at' => date('d/m/Y'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDr()
    {
        return $this->hasOne(Odonto::className(), ['id' => 'id_dr']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCliente()
    {
        return $this->hasOne(Paciente::className(), ['id' => 'id_cliente']);
    }

    public function beforeSave($insert) {

        if (parent::beforeSave($insert)) {

            $this->valor = str_replace(",", ".", $this->valor);

            return true;

        } else {

            return false;

        }

    }
}
