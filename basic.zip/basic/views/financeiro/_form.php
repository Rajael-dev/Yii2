<?php

use yii\helpers\Html;
use kartik\widgets\ActiveForm;
use kartik\builder\Form;
use app\controllers\FinanceiroController;

/* @var $this yii\web\View */
/* @var $model app\models\Financeiro */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="financeiro-form">

    <?php $form = ActiveForm::begin(); ?>

    <?php 
        echo Form::widget([
            'model' => $model,
            'form' => $form,
            'columns' => 6,
            'attributes' => [
                'data' => ['type' => Form::INPUT_WIDGET, 'columnOptions' => ['colspan' => 6],
                    'widgetClass' => '\kartik\widgets\DatePicker', 
                    'options' => [
                        'options' => [
                            'placeholder' => 'Data'
                        ],
                        'pluginOptions' => [
                            'autoclass' => true,
                        ],
                    ]
                ],

            ]
        ]);
        
        
        //echo $form->field($model, 'id')->textInput(); 
    ?>

    <?php 

        $formas = ['Dinheiro', 'Cheque a Vista', 'Cheque Pré', 'Débito', 'Crédito'];


    	echo Form::widget([
        'model' => $model,
        'form' => $form,
        'columns' => 6,
        'attributes' => [
            'forma' => ['type' => Form::INPUT_WIDGET, 'columnOptions' => ['colspan' => 6],
                'widgetClass' => '\kartik\widgets\Select2',
                'options' => [
                    'options' => [
                        'placeholder' => 'Selecione a Forma de Pagamento'
                    ],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                    'data' => $formas,
                ]
            ],
        ]
    ]);
    ?>

    <?= $form->field($model, 'valor')->textInput() ?>

    <?php 
        $odontos = \yii\helpers\ArrayHelper::map(\app\models\Odonto::find()->orderBy('nome')->asArray()->all(), 'id', 'nome');
        
        $pacientes = \yii\helpers\ArrayHelper::map(\app\models\Paciente::find()->orderBy('nome')->asArray()->all(), 'id', 'nome');


    	echo Form::widget([
        'model' => $model,
        'form' => $form,
        'columns' => 6,
        'attributes' => [
            'id_dr' => ['type' => Form::INPUT_WIDGET, 'columnOptions' => ['colspan' => 6],
                'widgetClass' => '\kartik\widgets\Select2',
                'options' => [
                    'options' => [
                        'placeholder' => 'Selecione o Odontologista'
                    ],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                    'data' => $odontos,
                ]
            ],
            'id_cliente' => ['type' => Form::INPUT_WIDGET, 'columnOptions' => ['colspan' => 6],
                'widgetClass' => '\kartik\widgets\Select2',
                'options' => [
                    'options' => [
                        'placeholder' => 'Selecione o Paciente'
                    ],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                    'data' => $pacientes,
                ]
            ],
        ]
    ]);
    ?>

    <?= $form->field($model, 'datacheque')->textInput() ?>

    <?= $form->field($model, 'parcelamentocartao')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Cadastrar', ['class' => 'btn btn-success']) ?>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Cadastrar e Adicionar Outro Pagamento', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
