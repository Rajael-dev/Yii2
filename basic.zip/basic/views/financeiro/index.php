<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Financeiros';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="financeiro-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Financeiro', ['create'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [

            'id_cliente',
            [
                'attribute' => 'data',
                'value' =>  function($model) { return Yii::$app->formatter->asDate($model->data, Yii::$app->formatter->dateFormat); }
            ],            'forma',
            'valor',
            'id_dr',
            //'datacheque',
            //'parcelamentocartao',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
